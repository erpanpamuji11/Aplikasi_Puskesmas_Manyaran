
import 'package:flutter/material.dart';
import 'package:puskesmas_manyaran/notification_page.dart';
import 'package:puskesmas_manyaran/poli_page.dart';
import 'package:puskesmas_manyaran/tambah_pasien/TambahPasienBaru.dart';
import 'package:puskesmas_manyaran/tambah_pasien/TambahPasienLama.dart';

class home_screen extends StatelessWidget {
  const home_screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size; //untuk menyesuaikan layar
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            //inii inisialisasi bila ukuran container 45% dari ukuran layar
            height: size.height * .50,
            decoration: BoxDecoration(
              color: Colors.teal,
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start ,
                children: <Widget>[
                  Align(
                    alignment: Alignment.topRight,
                    child: InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context){return notification_page();}));
                      },
                      child: Container(
                        alignment: Alignment.center,
                        height: 52,
                        width: 52,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.teal),
                        child: Icon(Icons.notifications_none, color: Colors.white,),
                      ),
                    ),
                  ),
                  Text('Puskesmas \nManyaran', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 36, color: Colors.white, fontFamily: 'ubuntu'),),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 30),
                    margin: EdgeInsets.only(top: 20, bottom: 30),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22 )
                    ),
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: "Cari poliklinik.....",
                        icon: Icon(Icons.search, color: Colors.teal,)
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(bottom: 10),
                    child: Text('Pendaftaran Pasien', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600),),
                  ),
                  Card(
                    margin: EdgeInsets.only(bottom: 20),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          ElevatedButton(
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context){
                                  return TambahPasienBaru();
                                }));
                              },
                              child: Text('Daftar Pasien Baru')),
                          Text('|', style: TextStyle(fontSize: 30, color: Colors.teal),),
                          ElevatedButton(
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context){
                                  return TambahPasienLama();
                                }));
                              },
                              child: Text('Daftar Pasien Lama'))
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.only(bottom: 10),
                    child: Text('Apa Kebutuhan Anda?', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600),),
                  ),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      childAspectRatio: .85,
                      mainAxisSpacing: 20,
                      crossAxisSpacing: 20,
                      children: <Widget>[
                        CategoriCard(
                          title: 'Daftar Poliklinik',
                          pngPic: 'assets/images/poli.jpg',
                        ),
                        CategoriCard(
                          title: 'Dokter dan Petugas',
                          pngPic: 'assets/images/docter.png',
                        ),
                        CategoriCard(
                          title: 'Fasilitas Puskesmas',
                          pngPic: 'assets/images/fasility.png',
                        ),
                        CategoriCard(
                          title: 'Tips Hidup Sehat',
                          pngPic: 'assets/images/tips.png',
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

class CategoriCard extends StatelessWidget {
  final String pngPic;
  final String title;
  const CategoriCard({Key? key, required this.pngPic, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: Container(
        // padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [BoxShadow(
                offset: Offset(0, 17),
                blurRadius: 17,
                spreadRadius: -23,
                color: Colors.grey
            )]
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: (){Navigator.push(context, MaterialPageRoute(builder: (context){return poli_page();}));},
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: <Widget>[
                  Image.asset(pngPic, height: 120,),
                  Spacer(),
                  Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontSize: 15),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

