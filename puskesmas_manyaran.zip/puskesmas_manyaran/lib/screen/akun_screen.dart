import 'package:flutter/material.dart';

class akun_screen extends StatelessWidget {
  const akun_screen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Akun'),
      ),
    );
  }
}
