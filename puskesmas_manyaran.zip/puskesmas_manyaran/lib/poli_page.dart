import 'package:flutter/material.dart';

class poli_page extends StatelessWidget {
  const poli_page({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Poliklinik'),
      ),
      body: Container(
        child: ListView(
          children: <Widget>[
            poli_list(
              text: 'Poliklinik Umum',
            ),
            poli_list(
              text: 'Poliklinik Anak',
            ),
            poli_list(
              text: 'Poliklinik THT',
            ),
            poli_list(
              text: 'Poliklinik Mata',
            ),
            poli_list(
              text: 'Poliklinik Orthopedi',
            ),
          ],
        ),
      ),
    );
  }
}

class poli_list extends StatelessWidget {

  final String text;
  const poli_list({Key? key, required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
          child: Card(
            margin: EdgeInsets.only(left: 10, right: 10, top: 2, bottom: 2),
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Text(text, style: TextStyle(fontSize: 18, color: Colors.teal),),
                  ),
                ],
              ),
            ),
          ),
        );
  }
}

