import 'package:flutter/material.dart';
import 'package:puskesmas_manyaran/antrianPasien.dart';

class TambahPasienBaru extends StatelessWidget {
  const TambahPasienBaru({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Halaman Daftar Pasien",
      theme: ThemeData(
        primarySwatch: Colors.teal,
        fontFamily: 'ubuntureg'
      ),
      home: DaftarPoli(),
    );
  }
}

class DaftarPoli extends StatefulWidget {
  const DaftarPoli({Key? key}) : super(key: key);

  @override
  _DaftarPoliState createState() => _DaftarPoliState();
}

class _DaftarPoliState extends State<DaftarPoli> {

  String nama = '';
  String poli = '';
  String alamat = '';
  String bpjs = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pendaftaran Pasien'),
      ),
      body: Container(
        margin: EdgeInsets.all(15.0),
        child: Form(
          child: Column(
            children: <Widget>[
              TextFormField(
                autofocus: true,
                decoration: InputDecoration(
                  hintText: 'Masukan Nama',
                  labelText: 'Nama',
                  border: OutlineInputBorder()
                ),
                keyboardType: TextInputType.text,
                onChanged: (text){
                  nama = text;
                },
                validator: (value){
                  if(value!.isEmpty){
                    return "Nama tidak boleh kosong!";
                  }
                },
              ),
              Container(height: 8.0),
              TextFormField(
                decoration: InputDecoration(
                    hintText: 'Masukan Alamat',
                    labelText: 'Alamat',
                    border: OutlineInputBorder()
                ),
                keyboardType: TextInputType.text,
                onChanged: (text){
                  alamat = text;
                },
                validator: (value){
                  if(value!.isEmpty){
                    return "Alamat tujuan tidak boleh kosong";
                  }
                },
              ),
              Container(height: 8.0),
              TextFormField(
                decoration: InputDecoration(
                    hintText: 'Masukan poliklinik',
                    labelText: 'Poliklinik',
                    border: OutlineInputBorder()
                ),
                keyboardType: TextInputType.text,
                onChanged: (text){
                  poli = text;
                },
                validator: (value){
                  if(value!.isEmpty){
                    return "Poliklinik tidak boleh kosong";
                  }
                },
              ),
              Container(height: 8.0),
              TextFormField(
                decoration: InputDecoration(
                    hintText: 'Masukan Nomor BPJS',
                    labelText: 'BPJS',
                    border: OutlineInputBorder()
                ),
                keyboardType: TextInputType.text,
                onChanged: (text){
                  bpjs = text;
                },
                validator: (value){
                  if(value!.isEmpty){
                    return "Nomor BPJS tidak boleh kosong";
                  }
                },
              ),
              Container(height: 10.0),
              ElevatedButton(
                  onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => antrianPasien(nama : nama, poli: poli, alamat: alamat, bpjs: bpjs,)
                    ));
                  },
                  child: Text('Daftar Pasien'))
            ],
          ),
        ),
      )
    );
  }
}

