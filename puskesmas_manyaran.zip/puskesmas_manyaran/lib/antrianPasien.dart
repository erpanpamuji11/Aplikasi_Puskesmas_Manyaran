import 'package:flutter/material.dart';

class antrianPasien extends StatefulWidget {

  String nama, poli, alamat, bpjs;
  antrianPasien({Key? key,required this.nama, required this.poli, required this.alamat, required this.bpjs}) : super(key: key);

  @override
  _antrianPasienState createState() => _antrianPasienState(nama, alamat, poli, bpjs);
}

class _antrianPasienState extends State<antrianPasien> {

  String nama, poli, alamat, bpjs;
  _antrianPasienState(this.nama, this.poli, this.alamat, this.bpjs);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Antrian Pasien'),
      ),
      body: Container(
        child: ListView(
          children: <Widget>[
            Card(
              margin: EdgeInsets.only(left: 10, right: 10, top: 20, bottom: 20),
              child: Padding(
                padding: EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Text('Nama         : $nama'),
                    ),
                    Container(
                      child: Text('Alamat       : $alamat'),
                    ),
                    Container(
                      child: Text('Poliklinik   : $poli'),
                    ),
                    Container(
                      child: Text('BPJS           : $bpjs'),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

