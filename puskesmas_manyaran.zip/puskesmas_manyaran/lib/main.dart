import 'package:flutter/material.dart';
import 'package:puskesmas_manyaran/screen/akun_screen.dart';
import 'package:puskesmas_manyaran/screen/bpjs_screen.dart';
import 'package:puskesmas_manyaran/screen/home_screen.dart';
import 'package:puskesmas_manyaran/screen/riwayat_screen.dart';

void main() {
  runApp(MainScreen());
}

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int pageIndex = 0;
  List<Widget> pageList = <Widget>[
    home_screen(),
    riwayat_screen(),
    bpjs_screen(),
    akun_screen()
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Puskesmas Manyaran',
      theme: ThemeData(primarySwatch: Colors.teal, fontFamily: 'ubuntureg'),
      home: Scaffold(
        body: pageList[pageIndex],
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.teal,
          selectedItemColor: Colors.teal,
          unselectedItemColor: Colors.grey,
          currentIndex: pageIndex,
          onTap: (value){
            setState(() {
              pageIndex = value;
            });
          },
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Riwayat'),
            BottomNavigationBarItem(icon: Icon(Icons.credit_card), label: 'BPJS'),
            BottomNavigationBarItem(icon: Icon(Icons.account_circle), label: 'Akun'),
          ],
        ),
      ),

    );
  }
}

