import 'package:flutter/material.dart';

class notification_page extends StatelessWidget {
  const notification_page({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notification'),
      ),
      body: Center(
        child: Text('Tidak ada pemberitahuan.....', style: TextStyle(fontSize: 20, color: Colors.teal),),
      ),
    );
  }
}
