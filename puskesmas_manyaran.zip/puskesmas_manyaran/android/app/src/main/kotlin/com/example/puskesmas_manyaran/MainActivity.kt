package com.example.puskesmas_manyaran

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
